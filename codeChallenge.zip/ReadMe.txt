Author: Luxi Zou
Date: 2015-09-28

Environment:
  The most recent node.js environment.

How to run:
  node traffic.js DATA_SET_PATH
  For example, in this folder, there are two data sets named data.json and dataSample.json.
  To analyze data.json:
    node traffic.js ./data.json
  To analyze dataSample.json:
    node traffic.js ./dataSample.json

The program was tested on Mac OS 10.10.5 (14F27)
Thanks for using.